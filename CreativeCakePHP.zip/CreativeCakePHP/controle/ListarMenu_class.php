<?php
	include_once("modelo/MenuDAO_class.php");

	class ListarMenu{
	
		public function __construct(){
			//****** acessar o modelo
			$dao = new MenuDAO();

			//iniciou a conexão com o BD
			$lista = $dao->listar();
			
			//vou passar a lista para a visão
			//****** acessar a visão
			include_once("visao/listaMenu.php");
		}
	}
?>