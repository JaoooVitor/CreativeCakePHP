<?php
	//include_once("../modelo/MenuDAO_class.php");
	include_once("modelo/MenuDAO_class.php");
	//include_once("../modelo/Menu_class.php");
	include_once("modelo/Menu_class.php");
	//include_once("../visao/formCadastroMenu.php");
	include_once("visao/formCadastroMenu.php");
	class CadastrarMenu{
	
		public function __construct(){
			
			if(isset($_POST["enviar"])){
				//formulário enviar foi enviado
				
				$d = new Menu();
				
				
				$fotoNome = $_FILES["foto"]["name"];
				$fotoCaminhoTemporario = $_FILES["foto"]["tmp_name"];
				move_uploaded_file($fotoCaminhoTemporario, "imagens/{$fotoNome}");
				
				$d->setFoto("imagens/{$fotoNome}");

				$d->setProduto($_POST["produto"]);
				$d->setValor($_POST["valor"]);

				//$d->setFoto($_POST["foto"]);
				
				$dao = new MenuDAO();
				
				$dao->cadastrar($d);
				
				$status = "Cadastro de " . $d->getProduto() . " no Menu realizado   
				com sucesso";

                $lista = $dao->listar();
				
				echo "sucesso";
			} else{
				include_once("visao/formCadastroMenu.php");
			}
		}
	}
?>
