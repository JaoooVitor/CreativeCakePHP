<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creative Cake</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="visao/estilos/style.css">

</head>
<body>

<header class="header">

    <a href="#home" class="logo">
        <img src="visao/imagens/logocreativecake_resized.png" alt="">
    </a>

    <nav class="navbar">
        <a href="#home">Home</a>
        <a href="menu.php?fun=cadastrar">Cadastrar</a>
        <a href="#menu">Menu</a>
        <a href="#products">Produtos</a>
        <a href="#review">Avaliações</a>
    </nav>

    <div class="icons">
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-shopping-cart" id="cart-btn"></div>
    </div>

</header>

<style>
.home{
    min-height: 100vh;
    display: flex;
    align-items: center;
    background:url(visao/imagens/fundo2_resized.jpeg) no-repeat;
    background-size: cover;
    background-position: center;
}
</style>