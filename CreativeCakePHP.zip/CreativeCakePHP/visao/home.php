<section class="home" id="home">

    <div class="content">
        <h3>Tradição, sabor e qualidade!</h3>
        <p>Aqui na Creative Cake, cuidamos de cada detalhe para que você tenha o prazer de saborear uma sobremesa diferenciada. Conheça nossos diferenciais!</p>
        <a href="#" class="btn">Faça sua encomenda</a>
    </div>

</section>