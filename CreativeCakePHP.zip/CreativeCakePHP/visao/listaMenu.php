<?php
    define('BASE_DIR','/CreativeCakePHP/visao/');
    //assume que o controle passou uma lista
    echo "<h1 class='heading'><span>Menu</span> </h1>";
    echo "<section class='menu' id='menu'>";
    foreach($lista as $c){
        echo "<div class='box-container'>";
        echo "<div class='box'>";
            echo "<img src='". BASE_DIR. $c->getFoto(). "' alt=''>";
            echo "<h3>". $c->getProduto() ."</h3>";
            echo "<div class='price'>R$ " .$c->getValor() ."</div>";
            echo "<a href='#' class='btn'>Adicionar ao carrinho</a>";
        echo "</div>";
        
    }
    echo "</section>";

?>