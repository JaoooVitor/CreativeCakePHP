<section class="footer">

    <div class="share">
        <a href="#" class="fab fa-facebook-f"></a>
        <a href="https://instagram.com/creativecakeudia?igshid=NjIwNzIyMDk2Mg==" class="fab fa-instagram"></a>
        <a href="#" class="fab fa-whatsapp"></a>
        <a href="https://youtu.be/v1LpqMdDc-g?si=Uo66yvzmEGaZsSIK" class="fab fa-youtube"></a>
    </div>

    <div class="links">
        <a href="#home">Home</a>
        <a href="#about">Sobre</a>
        <a href="#menu">Menu</a>
        <a href="#products">Produtos</a>
        <a href="#reviews">Avaliações</a>
    </div>

    <div class="credit">Criado por <span>João Vítor</span> | todos os direitos reservados.</div>

</section>