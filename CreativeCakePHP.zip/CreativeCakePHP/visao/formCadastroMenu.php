<HTML>
	<HEAD>
		<TITLE> Cadastrar Menu </TITLE>
		<META charset="UFT-8" />
	</HEAD>
	
	<BODY>
		<H1> Cadastrar Menu </H1>
		
		<FORM action="menu.php?fun=cadastrar" method="POST" enctype="multipart/form-data">
		<!-- POST -> envio de informações escondidas -->
		<LABEL for="foto"> Foto: </LABEL> 
		<input type="file" id="foto" name="foto" accept="image/png, image/jpeg" /><br><br>

		<LABEL for="produto"> Nome do produto: </LABEL> 
		<textarea type="text" name="produto" id="produto"></textarea><br><br>

		<label for="valor">Valor</label>
		<input type="text" name="valor" id="valor">

		
		<input type="submit" name="enviar" value="enviar">

		</FORM>
	
	</BODY>

</HTML>