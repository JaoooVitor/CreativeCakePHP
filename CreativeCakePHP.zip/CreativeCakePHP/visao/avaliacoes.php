<section class="review" id="review">

    <h1 class="heading"> <span>Avaliações</span> dos clientes </h1>

    <div class="box-container">

        <div class="box">
            <img src="visao/imagens/quote-img_resized.png" alt="" class="quote">
            <p>WOW... LOOK AT HIIIM! Parece que você é uma boa confeiteira não é mesmo? Seu bolo estava tão AESTHETIC. Eu já tenho o meu veredito!<BR>
            THIS IS PERFECT.</p>
            <img src="visao/imagens/avaliação1_resized.jpg" class="user" alt="">
            <h3>Rogrigo Goes</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
        </div>

        <div class="box">
            <img src="visao/imagens/quote-img_resized.png" alt="" class="quote">
            <p>Isso aqui não tem como po, a verdade tem que ser falada aqui! Isso aqui é a Elite da<BR>
            ELITE.</P>
            <br><br><br><br>
            <img src="visao/imagens/avaliaçao2_resized.jpg" class="user" alt="">
            <h3>Cazé</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
        </div>
        
        <div class="box">
            <img src="visao/imagens/quote-img_resized.png" alt="" class="quote">
            <p>Shinzou wo sasageyo<br>
            TATAKAEEEE</p>
            <br><br><br><br><br><br>
            <img src="visao/imagens/avaliaçao3_resized.jpg" class="user" alt="">
            <h3>Eren</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
        </div>

    </div>

</section>