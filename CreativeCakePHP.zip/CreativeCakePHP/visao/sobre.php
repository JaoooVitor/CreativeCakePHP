<section class="about" id="about">

    <h1 class="heading"> <span>Sobre</span></h1>

    <div class="row">

        <div class="image">
            <img src="visao/imagens/about_resized.jpeg" alt="">
        </div>

        <div class="content">
            <h3>Olá, prazer!</h3>
            <p>O meu nome é Elisangela, eu sou a Chef Confeiteira responsável e apaixonada por todos os bolos e doces da Creative Cake. </p>
            <p>Eu sou apaixonada pelo o que faço e essa paixão me motivou a fundar a Creative Cake, uma confeitaria especializada em Bolos Festivos e outras diversas sobremesas. Um lugar onde a mágica acontece e desejos se tornam realidade.</p>
            <p>Seja bem vindo a um mundo cheio de possibilidades, encanto e doçura!</p>
            <a href="#" class="btn">Saiba mais</a>
        </div>

    </div>

</section>