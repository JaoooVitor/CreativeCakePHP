<?php
    class Menu{

        private $id;
        private $foto;
        private $produto;
        private $valor;

        public function __contruct(){
        }

        public function setId($id){
            $this->id = $id;
        }

        public function setFoto($foto){
            $this->foto = $foto;    
        }

        public function setProduto($produto){
            $this->produto = $produto;    
        }
        public function setValor($valor){
            $this->valor = $valor;    
        }

        public function getId(){
            return $this->id;
        }

        public function getFoto(){
            return $this->foto;    
        }

        public function getProduto(){
            return $this->produto;   
        }
        public function getValor(){
            return $this->valor;    
        }
        
    }
?>