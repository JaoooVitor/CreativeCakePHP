<?php
session_start();
//ROTEADOR
	//GET -> função que deixa variáveis explicitas na URL
	//recebe o comportamento que será executado por GET
	//array chamado $_GET e os índices são as variáveis
	//localhost/agenda/contato.php?fun=alterar
	
	
	if(isset($_GET["fun"])){
		//is + set => é setado? T Está vazio? F
	
		$fun = $_GET["fun"];
		
		if($fun == "cadastrar"){
			include_once("controle/CadastrarMenu_class.php");
			$pag = new CadastrarMenu();
			
		} elseif($fun == "alterar"){
			include_once("controle/AlterarMenu_class.php");
			$pag = new AlterarMenu();
			
		} elseif($fun == "excluir"){
			
			include_once("controle/ExcluirMenu_class.php");//op == sim
			$pag = new ExcluirMenu();
			
		} elseif($fun == "listar"){
			include_once("controle/ListarMenu_class.php");
			$pag = new ListarMenu();
			
		}  elseif($fun == "exibir") {
			include_once("controle/ExibirMenu_class.php");
			$pag = new ExibirMenu();
			
		} else {
			include_once("controle/ListarMenu_class.php");
			$pag = new ListarMenu();			
		}
		
		
	} else {
		include_once("controle/ListarMenu_class.php");
		$pag = new ListarMenu();
	}
?>